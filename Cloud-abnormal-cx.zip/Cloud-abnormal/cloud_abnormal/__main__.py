from __future__ import annotations

import argparse
import json

from .config import load_config
from .pipeline import evaluate_dataset, fit_dataset


def parser() -> argparse.ArgumentParser:
    result = argparse.ArgumentParser(description="Frozen Qwen2.5-VL + DINOv3 cloud anomaly detection")
    result.add_argument("--config", default="configs/default.yaml")
    sub = result.add_subparsers(dest="command", required=True)
    for name in ("fit", "evaluate"):
        item = sub.add_parser(name)
        item.add_argument("--dataset", choices=("mvtec", "visa"), required=True)
        item.add_argument("--root", help="Override dataset root")
        item.add_argument("--memory-dir", default="outputs/memory")
        if name == "evaluate":
            item.add_argument("--use-7b", action="store_true")
            item.add_argument("--disable-qwen", action="store_true")
    return result


def main() -> None:
    args = parser().parse_args()
    cfg = load_config(args.config)
    default_root = cfg.data.mvtec_root if args.dataset == "mvtec" else cfg.data.visa_root
    root = args.root or default_root
    if args.command == "fit":
        fit_dataset(cfg, args.dataset, root, args.memory_dir)
    else:
        metrics = evaluate_dataset(
            cfg, args.dataset, root, args.memory_dir, use_7b=args.use_7b, disable_qwen=args.disable_qwen
        )
        print(json.dumps(metrics["overall"], indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()

